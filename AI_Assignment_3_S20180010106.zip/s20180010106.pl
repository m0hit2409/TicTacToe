species-name(african-wild-dog, lycaon-pictus).
species-name(common-fox, vulpes-vulpes).
species-name(arctic-fox, vulpes-lagopus).
species-name(fennec-fox, vulpes-zerda).
species-name(red-wolf, canis-rufus).
species-name(coyote, canis-latrans).
species-name(gray-wolf, canis-lupus).
species-name(dog, canis-lupus).

sub-species-species-name(canis-lupus-familiaris, canis-lupus).

sub-species-name(dog, canis-lupus-familiaris).


species-genus(lycaon-pictus, lycaon).
species-genus(vulpes-vulpes, vulpes).
species-genus(vulpes-lagopus, vulpes).
species-genus(vulpes-zerda, vulpes).
species-genus(canis-rufus, canis).
species-genus(canis-latrans, canis).
species-genus(canis-lupus, canis).
species-genus(canis-lupus-familiaris, canis).

genus-family(lycaon, canidae).
genus-family(vulpes, canidae).
genus-family(canis, canidae).

list-append(A, T, [A|T]).


common-genus(X, Y):-
    species-name(X, S1),
    species-genus(S1, G),
    species-name(Y, S2),
    species-genus(S2, G).


common-species(X, Y):-
    species-name(X, S),
    species-name(Y, S).


get-family(X):-
    genus-family(canis, X).


family-line(dog, X):-
    list-append(dog, [], L1),
    sub-species-name(dog, Ss),
    list-append(Ss, L1, L2),
    species-name(dog, S),
    list-append(S, L2, L3),
    species-genus(S, G),
    list-append(G, L3, L4),
    genus-family(G, F),
    list-append(F, L4, X),!.

family-line(Cname, X):-
    species-name(Cname, S),
    species-genus(S, G),
    genus-family(G, F),
    list-append(Cname, [], L1),
    list-append(S, L1, L2),
    list-append(G, L2, L3),
    list-append(F, L3, X).


are-equal(X, X).

get-path(_,A,A,X):-
    last(A,X),!.
get-path(A, [HA|TA], [HB|TB], X):-
    \+are-equal(HA, HB),
    list-append(A, [HB|TB], L),
    reverse([HA|TA], R),
    append(R,L,X),!.
get-path(_, [HA|TA], [HB|TB], X):-
    are-equal(HA, HB),
    get-path(HA, TA, TB, X).


relation-path(A, B, X):-
    family-line(A, LA),
    family-line(B, LB),
    get-family(F),
    get-path(F,LA, LB, X).
